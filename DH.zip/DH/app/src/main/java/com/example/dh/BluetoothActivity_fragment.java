package com.example.dh;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class BluetoothActivity_fragment extends Fragment implements View.OnClickListener{
    String TAG = "BluetoothActivity_fragment";
    UUID BT_MODULE_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); // "random" unique identifier
    BluetoothAdapter btAdapter;
    Set<BluetoothDevice> pairedDevices;
    ArrayAdapter<String> btArrayAdapter;
    ArrayList<String> deviceAddressArray;
    TextView Status;
    Button btnParied, bthSearch, btnSend;
    ListView listView;
    BluetoothSocket btSocket = null;
    ConnectedThread connectedThread;
    private  final static int REQUEST_BT = 1;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.bluetooth_fragment, container, false);
        Status = (TextView)rootView.findViewById(R.id.text_status);
        btnParied = (Button)rootView.findViewById(R.id.btn_paired);
        bthSearch = (Button)rootView.findViewById(R.id.btn_search);
        btnSend = (Button)rootView.findViewById(R.id.btn_send);
        listView = (ListView)rootView.findViewById(R.id.listview);
        //블루투스 활성화
        btAdapter = BluetoothAdapter.getDefaultAdapter();
        if(!btAdapter.isEnabled()){
            Intent enableBluetoothIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBluetoothIntent, REQUEST_BT);
        }
        //페어링 장치 표시 (리스트뷰에 페어링 된 기기 뿌려주기
        btArrayAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1);
        deviceAddressArray = new ArrayList<>();
        listView.setAdapter(btArrayAdapter);

        listView.setOnItemClickListener(new myOnItemClickListener());
        return rootView;
    }

    // 브로드캐스트 수신기 - 검색된 기기의 정보를 가져오기
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                //검색을 통한 블루투스 장치 가져오기
                //인텐트에서 객체 정보 불러오기
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                String deviceName = device.getName();
                String deviceHardwareAddress = device.getAddress(); // MAC 주소
                btArrayAdapter.add(deviceName);
                deviceAddressArray.add(deviceHardwareAddress);
                btArrayAdapter.notifyDataSetChanged();
            }
        }
    };

    @Override
    public void onDestroy() {
        super.onDestroy();
        // ACTION_FOUND 수신기 등록 취소
        LocalBroadcastManager.getInstance(getContext()).unregisterReceiver(receiver);
    }

    @Override
    public void onClick(View view) {
        //프래그먼트에 존재하는 뷰 아이디를 매개변수로 사용
        switch(view.getId()){
            case R.id.btn_paired:
                btArrayAdapter.clear();
                if(deviceAddressArray!=null && !deviceAddressArray.isEmpty()){ deviceAddressArray.clear();}
                //getBondedDevices를 통해서 페어링된 목록 가져오기
                pairedDevices = btAdapter.getBondedDevices();
                if (pairedDevices.size() > 0) {
                    for (BluetoothDevice device : pairedDevices) {
                        String deviceName = device.getName();
                        String deviceHardwareAddress = device.getAddress(); // MAC주소 불러오기
                        //디바이스 이름은 btArrayAdapter에, 디바이스주소는 deviceAddressArray에
                        //기기를 검색하고 페어링 된 기기 목록을 불러올 때 btArrayAdapter, DevicesAddressArray를 같이 쓰기에
                        //버튼을 누를 때 마다 Array에 들어있던 값들을 모두 clear
                        btArrayAdapter.add(deviceName);
                        deviceAddressArray.add(deviceHardwareAddress);
                    }
                }
                break;
            case R.id.btn_search:
                // 검색중인지 체크
                if(btAdapter.isDiscovering()){
                    btAdapter.cancelDiscovery();
                } else {
                    if (btAdapter.isEnabled()) {
                        //주변 기기 검색
                        btAdapter.startDiscovery();
                        btArrayAdapter.clear();
                        if (deviceAddressArray != null && !deviceAddressArray.isEmpty()) {
                            deviceAddressArray.clear();
                        }
                        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
                        LocalBroadcastManager.getInstance(getContext()).registerReceiver(receiver,filter);
                    } else {
                        Toast.makeText(getContext(), "블루투스가 비활성화 되어있습니다.", Toast.LENGTH_SHORT).show();
                    }
                }
                break;
            case R.id.btn_send:
                if(connectedThread!=null){ connectedThread.write("a"); }
                break;
            default:
                break;
        }
    }

    public class myOnItemClickListener implements AdapterView.OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Toast.makeText(getContext(), btArrayAdapter.getItem(position), Toast.LENGTH_SHORT).show();

            Status.setText("try...");

            final String name = btArrayAdapter.getItem(position); // get name
            final String address = deviceAddressArray.get(position); // get address
            boolean flag = true;

            BluetoothDevice device = btAdapter.getRemoteDevice(address);

            // create & connect socket
            try {
                btSocket = createBluetoothSocket(device);
                btSocket.connect();
            } catch (IOException e) {
                flag = false;
                Status.setText("연결에 실패하였습니다.");
                e.printStackTrace();
            }

            if(flag){
                Status.setText("연결되었습니다. / 이름 : "+name);
                connectedThread = new ConnectedThread(btSocket);
                connectedThread.start();
            }

        }
    }
    private BluetoothSocket createBluetoothSocket(BluetoothDevice device) throws IOException {
        try {
            final Method m = device.getClass().getMethod("createInsecureRfcommSocketToServiceRecord", UUID.class);
            return (BluetoothSocket) m.invoke(device, BT_MODULE_UUID);
        } catch (Exception e) {
            Log.e(TAG, "RFCOM 연결을 만들 수 없습니다.",e);
        }
        return  device.createRfcommSocketToServiceRecord(BT_MODULE_UUID);
    }
}
