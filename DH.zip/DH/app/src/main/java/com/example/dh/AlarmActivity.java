package com.example.dh;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.larswerkman.holocolorpicker.SaturationBar;

import petrov.kristiyan.colorpicker.ColorPicker;

public class AlarmActivity extends AppCompatActivity {
    String topic = "/IOT/MOOD/PUB";        //mqtt를 위한 토픽
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);
        ColorPicker picker = (ColorPicker)findViewById(R.id.picker);
        //SVBar svBar = (SVBar) findViewById(R.id.svbar);        //4가지 항목이 있지만 원하는 항목 하나만 적용
        //OpacityBar opacityBar = (OpacityBar) findViewById(R.id.opacitybar);
        SaturationBar saturationBar = (SaturationBar) findViewById(R.id.saturationbar);
        //ValueBar valueBar = (ValueBar) findViewById(R.id.valuebar);
        //picker.addSVBar(svBar);
        //picker.addOpacityBar(opacityBar);
        picker.addSaturationBar(saturationBar);
        //picker.addValueBar(valueBar);
        picker.getColor();        //원 스크롤을 돌려서 색상값을 가져옴
        if(oldColor != 0){        //이전의 색상설정이 있으면 표시
            picker.setOldCenterColor(oldColor);
        }else{
            picker.setOldCenterColor(picker.getColor());
        }
    }
    public void getColor(View view){
        oldColor = picker.getColor();        //원 스크롤을 돌려서 색상값을 가져옴
        picker.setOldCenterColor(oldColor);
        System.out.println(picker.getColor());
        String col = Integer.toHexString(picker.getColor());        //int형으로 값을 가져오는데 16진수로 변환한다.
        System.out.println(col);
        publishMessage(topic, col);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.reservation_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = new Intent(this, ReserveActivity.class);
        startActivity(intent);
        return super.onOptionsItemSelected(item);
    }
}